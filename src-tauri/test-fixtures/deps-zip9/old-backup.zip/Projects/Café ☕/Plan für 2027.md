# Plan für 2027

Café ☕: CRLF and LF line endings stay as written.

# a\..\b
One Fedora file whose name holds a backslash, two dots and a backslash.

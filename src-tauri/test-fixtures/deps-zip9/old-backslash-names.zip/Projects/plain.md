An ordinary note.

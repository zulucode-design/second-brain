In a folder named x\y.

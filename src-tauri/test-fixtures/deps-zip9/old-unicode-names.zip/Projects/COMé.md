Not a serial port.

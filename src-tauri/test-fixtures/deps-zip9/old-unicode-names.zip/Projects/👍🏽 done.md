An emoji with a skin tone modifier.
